﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameManager : MonoBehaviour {

    public GameObject Player;
    public GameObject camera;

	// Use this for initialization
	void Start () {
        /*if(StaticValue.from == 3)
        {
            Player.transform.position = new Vector2((float)18.15, (float)-1.26);
            camera.transform.position = new Vector2((float)13.75, 0);
            StaticValue.from = 0;
        }
        else if(StaticValue.from == 2 && StaticValue.HaveReadWaterTalk == 1)
        {
            Player.transform.position = new Vector2((float)-7.2, (float)-1.26);
            camera.transform.position = new Vector2((float)-2.46, 0);
            StaticValue.from = 0;
        }
        else if (StaticValue.from == 1)
        {
            Player.transform.position = new Vector2((float)-7.4, (float)-1.26);
            camera.transform.position = new Vector2((float)-2.46, 0);
            StaticValue.from = 0;
        }*/
    }
	
	// Update is called once per frame
	void Update () {
		
	}
}
